package uniandes.dpoo.estructuras.tests;

import org.junit.Assert;
import org.junit.Test;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;

import uniandes.dpoo.estructuras.model.MedioDePago;
import uniandes.dpoo.estructuras.Inventarios.InventarioMediosPago;




public class MedioDePagoTest {

    private InventarioMediosPago inventario = new InventarioMediosPago();

    @BeforeEach
    public void setUp() {
        inventario = new InventarioMediosPago();
    }

    @Test
    public void testAgregarMedioDePago() {
        MedioDePago medioDePago = new MedioDePago("Tarjeta de crédito");
        inventario.agregarMedioPago(medioDePago);
        Assert.assertEquals(medioDePago, inventario.buscarMedioPago("Tarjeta de crédito"));
    }

    @Test
    public void testEliminarMedioDePago() {
        MedioDePago medioDePago = new MedioDePago("Efectivo");
        inventario.agregarMedioPago(medioDePago);
        try {
            inventario.quitarMedioPago(medioDePago);
        } catch (Exception e) {
            Assert.fail("No debería lanzar excepción");
        }
        Assert.assertNull(inventario.buscarMedioPago("Efectivo"));
    }

    @Test
    public void testBuscarMedioDePagoExistente() {
        MedioDePago medioDePago = new MedioDePago("Tarjeta de débito");
        inventario.agregarMedioPago(medioDePago);
        MedioDePago medioEncontrado = inventario.buscarMedioPago("Tarjeta de débito");
        Assert.assertNotNull(medioEncontrado);
        Assert.assertEquals(medioDePago, medioEncontrado);
    }

    @Test
    public void testBuscarMedioDePagoNoExistente() {
        MedioDePago medioDePago = new MedioDePago("Transferencia bancaria");
        inventario.agregarMedioPago(medioDePago);
        MedioDePago medioEncontrado = inventario.buscarMedioPago("Tarjeta de crédito");
        Assert.assertNull(medioEncontrado);
    }

    @AfterEach
    public void tearDown() {
        inventario = null;
    }
}
