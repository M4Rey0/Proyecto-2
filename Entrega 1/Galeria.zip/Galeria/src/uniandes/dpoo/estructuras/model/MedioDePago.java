package uniandes.dpoo.estructuras.model;

public class MedioDePago {
    private String tipo;

    public MedioDePago(String tipo) {
        this.tipo = tipo;
    }

    public MedioDePago(){
    }

    @Override
    public String toString() {
        return tipo + ",";
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof MedioDePago){
            MedioDePago medioDePago = (MedioDePago) obj;
            return medioDePago.getTipo().equals(this.getTipo());
        }
        return false;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
}
