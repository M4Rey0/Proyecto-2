package uniandes.dpoo.estructuras.Consolas;

public class MainUtils {
    public void imprimirMenuSubastas(){
        
    }
}
