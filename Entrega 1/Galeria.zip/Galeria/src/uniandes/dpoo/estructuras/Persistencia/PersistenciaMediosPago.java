package uniandes.dpoo.estructuras.Persistencia;

import java.io.IOException;


import uniandes.dpoo.estructuras.Inventarios.InventarioMediosPago;
import uniandes.dpoo.estructuras.model.MedioDePago;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;

public class PersistenciaMediosPago {
    private static final String FILE_PATH = "data/MediosPago/";
    public static final String Assert = null;
    private PersistenciaUtils persistenciaUtils = new PersistenciaUtils();

    public void guardarMedioDePago(MedioDePago medioDePago) throws Exception {
        String path = FILE_PATH + medioDePago.getTipo() + ".txt";
        String contenido = medioDePago.toString();
        String clase = "MedioDePago";
        persistenciaUtils.guardarElemento(path, contenido, clase);
    }

    public MedioDePago cargarMedioDePago(String texto){
        String[] partes = texto.split(",");
        return new MedioDePago(partes[0]);
    }

    public void eliminarMedioDePago(MedioDePago medioDePago) throws Exception {
        String path = FILE_PATH + medioDePago.getTipo() + ".txt";
        persistenciaUtils.eliminarElemento(path, "MedioDePago", medioDePago.getTipo());
    }
    
    public InventarioMediosPago cargarMediosDePago(InventarioMediosPago inventarioMediosPago) throws RuntimeException{
            try {
                File directory = new File(FILE_PATH);
                File[] files = directory.listFiles();
                if (files != null) {
                    for (File file : files) {
                        if (file.isFile()) {
                            String contenido = new String(Files.readAllBytes(Paths.get(file.getPath())));
                            MedioDePago medioDePago = cargarMedioDePago(contenido);
                            inventarioMediosPago.agregarMedioPago(medioDePago);
                        }
                    }
                }
                return inventarioMediosPago;
            } catch (IOException e) {
                System.out.println("Error al cargar los medios de pago: " + e.getMessage());
                throw new RuntimeException("Error al cargar los medios de pago");
            }
        }


}
