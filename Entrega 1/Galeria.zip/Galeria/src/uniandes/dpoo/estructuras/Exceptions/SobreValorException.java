package uniandes.dpoo.estructuras.Exceptions;

public class SobreValorException extends Exception {
    public SobreValorException(String message) {
        super(message);
    }
}
