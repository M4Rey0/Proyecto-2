package uniandes.dpoo.estructuras.Inventarios;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import uniandes.dpoo.estructuras.model.Compra;

public class InventarioCompras {
    private Map<Integer, Compra> compras = new HashMap<>();
    private Map<Integer, ArrayList<Integer>> comprasSegunComprador = new HashMap<>();

    public InventarioCompras() {
    }

    public void agregarCompra(Compra compra) {
        compras.put(compra.getId(), compra);
        if (!comprasSegunComprador.containsKey(compra.getComprador())) {
            ArrayList<Integer> lista = new ArrayList<>();
            lista.add(compra.getId());
            comprasSegunComprador.put(compra.getComprador(), lista);
        } else {
            ArrayList<Integer> compras = comprasSegunComprador.get(compra.getComprador());
            compras.add(compra.getId());
            comprasSegunComprador.put(compra.getComprador(), compras);
        }
    }

    public void quitarCompra(Compra compra) throws Exception {
        if (!compras.containsKey(compra.getId())) {
            throw new Exception("La compra no se encuentra en el inventario");
        } else {
            compras.remove(compra.getId());
        }
    }

    public Compra getCompraPorId(int id) {
        return compras.get(id);
    }
}
